# Clinical Case Report → Exam Flashcards

Two-script workflow for finding open-access clinical case reports by medical specialty and converting them into exam-style Anki cards.

## What is included

- `specialty_harvest.py`: searches Europe PMC, limits retrieval to case-report records with open-access full text, downloads JATS XML, applies a transparent specialty-relevance and educational-value score, and writes a resumable case library.
- `cases2anki.py`: parses JATS, extracts diagnosis/investigations/management/outcome/teaching material, builds diagnosis and supporting exam cards, embeds a source link and reading panel, and exports `.apkg`, `.tsv`, or both.
- `tests/test_pipeline.py`: offline unit tests using a synthetic JATS article; no live API calls are made by the tests.

## Install

Python 3.10 or newer is recommended.

```bash
python -m pip install -r requirements.txt
```

The harvester itself uses only Python's standard library. `genanki` is needed only for `.apkg` output; `.tsv` works without it.

## Example workflow

Harvest Urology and Cardiology reports from 2018 onward:

```bash
python specialty_harvest.py --specialty urology cardiology --year-from 2018 --limit 40 --sort citations --output case_library
```

Use `--sort newest` for recent reports or `--sort relevance` for Europe PMC's default relevance order. The default `citations` order favors established, cited reports; the local educational score then ranks the downloaded cases by their teaching features.

Harvest all supported specialties (this can retrieve many records):

```bash
python specialty_harvest.py --specialty all --limit 20 --output case_library
```

Create Anki packages and a TSV import file:

```bash
python cases2anki.py case_library --format both --output decks/clinical_cases --deck "Clinical Case Reports" --quality-report --preview
```

Create only a TSV file without installing `genanki`:

```bash
python cases2anki.py case_library --format tsv --output decks/clinical_cases
```

For a focused specialty deck, metadata is read from each harvested case. To override it:

```bash
python cases2anki.py case_library/urology --specialty urology --format both --output decks/urology_cases
```

## Supported specialty keys

`anesthesia`, `cardiology`, `cardiothoracic-surgery`, `dermatology`, `emergency-medicine`, `endocrinology`, `gastroenterology`, `general-surgery`, `hematology`, `infectious-disease`, `nephrology`, `neurology`, `neurosurgery`, `obstetrics-gynecology`, `oncology`, `ophthalmology`, `orthopedics`, `otolaryngology`, `pediatrics`, `psychiatry`, `pulmonology`, `radiology`, `rheumatology`, `urology`, `vascular-surgery`.

Aliases include `ent`, `obgyn`, `gastro`, `ortho`, `peds`, `uro`, `vascular`, and `ct-surgery`.

## Quality and safety design

- **Only open-access full text:** search requires Europe PMC's `OPEN_ACCESS:Y` and `HAS_FT:Y` filters; only PMCIDs with downloadable JATS are retained.
- **Specialty second-pass:** articles are checked locally against their title, abstract and body to reduce false-positive specialty matches.
- **Transparent educational score:** unusual presentation, diagnostic investigations, pathological confirmation, management, follow-up and explicit teaching points contribute to a 0–100 score. Citation count is only a minor signal; it is not a clinical-quality measure.
- **No invented treatment advice:** management cards ask what the case report actually did and explicitly label it as case-reported management, not a universal recommendation.
- **Low-confidence diagnosis:** diagnosis cards have confidence thresholds, and `--quality-report` exposes the diagnosis source and confidence for manual checking.
- **Full reading panel:** cards include extracted article sections and a source link. The original JATS XML remains in the case library.
- **Escaping and stable identifiers:** article text is HTML-escaped; stable note GUIDs reduce duplicate notes when regenerating a deck.

## Important limitations

Automated extraction cannot guarantee that every diagnosis, section heading or clinical nuance is interpreted correctly. Articles use inconsistent JATS markup and narrative language, so **review the HTML preview and quality CSV before relying on cards for exams or clinical decisions**. The scripts do not generate new medical recommendations, validate current guidelines, or replace reading the cited article. Article copyright/licence terms still apply; the library is intended for personal study.

The harvester uses Europe PMC's public REST API. Search availability and article coverage depend on Europe PMC indexing and full-text deposit status; it does not retrieve every published case report worldwide.

## Offline tests

From this folder:

```bash
python -m unittest discover -s tests -v
python -m py_compile specialty_harvest.py cases2anki.py
```

### Importing the TSV into Anki

In Anki, choose **File → Import**, select the generated `.tsv`, set the separator to **Tab**, map the columns to `Front`, `Back`, `Extra`, and `Tags`, and enable **Allow HTML in fields**. Choose the target deck and an appropriate note type. The TSV header row names the fields; if your Anki version treats it as a note, enable the option that identifies the first row as field names.
