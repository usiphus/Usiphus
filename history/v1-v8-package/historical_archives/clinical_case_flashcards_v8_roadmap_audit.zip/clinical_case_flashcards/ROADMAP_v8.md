# Version 8.0 roadmap — visual, evidence-linked clinical case flashcards

**Status:** Proposed / not yet implemented.  
**Baseline inspected:** local V4.0 source (`specialty_harvest.py`, `cases2anki.py`) and V4/V5 roadmap documents.  
**Primary goal:** turn harvested open-access case reports into reliable, visually rich, exam-oriented Anki notes while keeping every clinical claim traceable to its source.

V8 should be delivered in small, testable releases. It must not sacrifice evidence traceability, source licensing, or safe clinical framing for more visually impressive cards.

## 1. Product goals and non-goals

### Goals

1. Harvest reproducibly and resume interrupted runs without losing earlier records.
2. Parse JATS as structured content, not just flattened text: sections, paragraphs, lists, tables, figures, captions, graphic references, and supplementary files.
3. Generate visual cards only when the source provides a suitable image or when the card is explicitly labelled as an original teaching illustration.
4. Support image occlusion, radiology/pathology recognition, ECG/clinical-sign recognition, flowcharts, and comparison cards.
5. Attach source identity, figure number, licence, evidence spans, and provenance to each card.
6. Validate exported notes before users import them into Anki.
7. Preserve stable note identity and avoid damaging existing Anki review history during updates.

### Non-goals

- Do not diagnose real patients or recommend treatment for an individual.
- Do not present case-report management as a guideline.
- Do not fabricate radiology, pathology, ECG, or clinical photographs and label them as real patient images.
- Do not redistribute publisher images or article text unless the licence permits it.
- Do not silently infer clinical interpretations from captions alone.

## 2. Proposed V8 architecture

```text
Europe PMC search
  -> candidate identity resolver
  -> resumable download manager
  -> article status / licence checks
  -> structured JATS parser
       |-> text sections and evidence spans
       |-> tables and table captions
       |-> figures, captions, graphic hrefs
       |-> supplementary assets
  -> specialty + clinical concept classifier
  -> evidence / assertion validator
  -> visual asset eligibility and processing
  -> card planner and card generators
  -> card quality + HTML + media validator
  -> TSV / APKG / audit report / preview
```

Keep the two-script interface initially. Extract shared logic into small modules only when tests show the boundaries are stable. Suggested future modules:

- `epmc_client.py` — HTTP, retry, throttling, pagination, API schemas.
- `jats_parser.py` — structured JATS parsing and media references.
- `evidence.py` — span IDs, offsets, provenance, assertion attributes.
- `visual_assets.py` — download, licence gate, image validation, crop/resize, OCR.
- `card_generators.py` — text and visual note types.
- `quality.py` — validation rules and quality reports.
- Keep `specialty_harvest.py` and `cases2anki.py` as stable CLI entry points.

## 3. Workstreams and implementation phases

### Phase 0 — baseline, contracts, and regression protection

- [ ] Record the current V4 behaviour and CLI defaults in tests.
- [ ] Add a machine-readable metadata schema with explicit `schema_version` and migration rules.
- [ ] Add fixture articles covering nested JATS sections, inline formulas, tables, figures, multiple abstracts, missing metadata, non-ASCII text, and malformed XML.
- [ ] Add golden-output tests for TSV, APKG note fields, HTML preview, and quality CSV.
- [ ] Add deterministic test fixtures with no live network dependency.
- [ ] Add a test command that runs unit tests, compile checks, and export smoke tests.

**Exit criteria:** existing V4 tests pass unchanged except for intentional bug-fix expectations; all new output schemas are documented.

### Phase 1 — harvester reliability and resumability

- [ ] Centralize all Europe PMC calls in one client with typed response validation.
- [ ] Honour both numeric and HTTP-date `Retry-After` values; retry 429 and transient 5xx responses with bounded exponential backoff and jitter.
- [ ] Add explicit connect/read timeouts, response-size ceilings, and useful error categories.
- [ ] Add configurable request rate and a shared limiter for every endpoint.
- [ ] Persist a run checkpoint after each candidate: discovered, downloaded, parsed, retained, rejected, or failed.
- [ ] Resume from checkpoint and retry only transient failures; do not repeat successful downloads unnecessarily.
- [ ] Add `--target-saved` with bounded refill: continue searching candidates until the target number of retained reports is reached or a maximum-candidate budget is exhausted.
- [ ] Preserve `--limit` as a candidate limit for backwards compatibility; use a distinct flag for target retained count.
- [ ] Add structured error codes, attempt counts, endpoint, timestamp, and retryability to `harvest_errors.jsonl`.
- [ ] Make writes safe for interrupted processes; use unique temporary files and atomic replacement.
- [ ] Validate manifest entries and report malformed lines instead of silently discarding them.
- [ ] Add a `--verify-cache` mode that checks XML hash, metadata schema, required files, and manifest consistency.

**Exit criteria:** interrupted and resumed runs produce the same retained article set as an uninterrupted run against the same fixture responses; no candidate is marked successful without valid XML and metadata.

### Phase 2 — article identity, status, and licence safety

- [ ] Resolve and store PMCID, PMID, DOI, Europe PMC ID, preprint/version-of-record links, and normalized title.
- [ ] Add Europe PMC article-status screening for retraction, correction, expression of concern, and update relationships.
- [ ] Add Crossref update metadata as a supplementary source where DOI resolution is available.
- [ ] Recheck status before card generation and record `status_checked_at`, status source, source URL, and update relation.
- [ ] Exclude retracted articles by default; require an explicit override and prominent card warning to include them for historical teaching.
- [ ] Normalize licence identifiers and distinguish known reuse permissions from unknown or missing licence text.
- [ ] Apply a strict visual-media gate: unknown/restricted licence means no copied image in exported deck; retain a citation and text-only alternative.
- [ ] Keep source attribution and figure attribution with every media asset.

**Exit criteria:** test cases for retracted, corrected, uncertain-status, missing-licence, and permissively licensed articles behave as specified.

### Phase 3 — structured JATS and media extraction

- [ ] Replace flattened `element_text(fig/table-wrap)` handling with typed JATS nodes.
- [ ] Preserve section hierarchy, paragraph boundaries, list items, table rows/cells, captions, labels, and references.
- [ ] Parse `graphic`, `inline-graphic`, `media`, `supplementary-material`, and `ext-link` references, including namespaced `xlink:href`.
- [ ] Resolve relative asset paths safely against the article asset endpoint; reject path traversal and unexpected hosts.
- [ ] Download image assets only when source and licence checks pass.
- [ ] Preserve original figure number, caption, alt text, MIME type, dimensions, source URL, checksum, and licence evidence.
- [ ] Support common formats (JPEG, PNG, TIFF where conversion is safe); reject SVG/script payloads unless sanitized by a dedicated safe renderer.
- [ ] Extract tables into structured rows rather than embedding them as a single string.
- [ ] Keep the original XML and its SHA-256 unchanged as the provenance anchor.

**Exit criteria:** parser fixtures prove that figure references and table structure survive parsing; invalid or disallowed assets are safely skipped with a report reason.

### Phase 4 — visual asset processing

- [ ] Create a deterministic media directory per article and stable asset IDs from source identity + figure ID + checksum.
- [ ] Validate MIME type from file content, not filename alone; enforce pixel and file-size limits.
- [ ] Generate thumbnails and high-resolution crops without modifying the preserved original.
- [ ] Add optional OCR for labels and annotations; store OCR text, engine/version, and confidence separately from article text.
- [ ] Detect low-resolution, blank, duplicate, unrelated, or mostly decorative images and reject them from card generation.
- [ ] Allow manually reviewed crop/region metadata for multi-panel figures.
- [ ] Keep image processing deterministic and test it with fixture images.
- [ ] Add a manual review queue for assets with uncertain caption/image match or uncertain reuse rights.

**Exit criteria:** every exported media file has a validated asset record, checksum, source, licence decision, and reason for inclusion.

### Phase 5 — visual card types

Prioritize in this order:

1. **Image occlusion anatomy / labelled figure cards**
   - One card per label or region, with hide-one and hide-many modes.
   - Store region geometry as normalized coordinates so it scales across screen sizes.
   - Keep a text alternative and source figure reference.
   - Use Anki's native Image Occlusion note type when compatibility is confirmed; otherwise export a documented fallback note type.

2. **Radiology recognition cards**
   - Front: source image or reviewed crop, optionally with numbered arrows.
   - Back: article-reported finding and diagnosis, with exact caption/evidence citation.
   - Never infer an imaging sign that the article does not explicitly support.

3. **Pathology / histology recognition cards**
   - Front: image or crop; back: reported histopathological description and diagnosis.
   - Keep stain, magnification, panel label, and source caption when available.

4. **ECG and clinical-sign cards**
   - Use only assets that are actually part of the article and have reuse permission.
   - Distinguish the article's interpretation from the converter's extracted text.

5. **Comparison cards**
   - Side-by-side source-supported comparison: e.g. two modalities, two stages, or normal/abnormal only when both examples exist.
   - Avoid inventing a normal comparator image.

6. **Diagnostic flowchart cards**
   - Generate only from explicit article-described steps or a separately licensed, dated guideline source.
   - Clearly label case-derived pathways versus guideline-derived pathways.

7. **Progressive reveal / annotated cards**
   - Reveal one label, region, or clue at a time; ensure the answer is not exposed in the front HTML or filename.

**Exit criteria:** each visual card type has an importable example, a rendered preview, an accessibility text alternative, and a quality test.

### Phase 6 — better exam-card generation

- [ ] Add explicit card schemas: `basic`, `cloze`, `vignette_diagnosis`, `next_investigation`, `reported_management`, `differential`, `complication`, `outcome`, `OSCE_viva`, `image_occlusion`, `radiology`, `pathology`, `comparison`, `flowchart`.
- [ ] Make question generation evidence-locked: every answer claim maps to one or more source spans or an external dated guideline source.
- [ ] Add evidence span IDs, section IDs, character offsets, quote text, and source hash to every card record.
- [ ] Separate article-reported facts, converter-generated prompts, OCR observations, and external guideline claims.
- [ ] Add a card planner that avoids generating multiple near-identical cards from the same paragraph or figure.
- [ ] Add specialty-specific templates without making specialty labels determine the answer.
- [ ] Add cloze cards only for concise, unambiguous facts; avoid clozing long paragraphs.
- [ ] Add next-best-investigation/management cards only when an independent guideline or validated pathway is supplied; case chronology alone is insufficient.
- [ ] Add OSCE/viva cards with structured sections: diagnosis, differential, investigations, interpretation, management, complications, counselling, and follow-up.
- [ ] Include uncertainty and evidence-strength labels; do not translate heuristic confidence into a clinical probability.

**Exit criteria:** every card has valid evidence references; unsupported answer claims fail validation or are explicitly marked for manual review.

### Phase 7 — quality gates and human review

- [ ] Add answer-leak detection (diagnosis or key phrase accidentally present on the front).
- [ ] Add duplicate-front and semantic-near-duplicate checks.
- [ ] Add HTML sanitization and broken-image/link detection.
- [ ] Add card length, readability, tag, and source-attribution checks.
- [ ] Add per-article and per-figure card caps to avoid card spam.
- [ ] Add image-caption mismatch checks and OCR confidence thresholds.
- [ ] Add a clinician-reviewed gold set across specialties, ages, and JATS structures.
- [ ] Report precision/recall for diagnosis extraction, assertion attributes, specialty classification, evidence-span accuracy, image selection, and card factuality.
- [ ] Show metrics per specialty and per card type, plus representative failure cases.
- [ ] Add review states: `auto_pass`, `needs_review`, `rejected`; do not silently promote low-confidence items.

**Exit criteria:** a versioned validation report is generated; high-risk card types cannot be exported as auto-approved without passing their checks.

### Phase 8 — Anki compatibility and update safety

- [ ] Define stable model IDs, note GUID rules, deck IDs, and field schemas centrally.
- [ ] Verify whether the installed Anki version supports native Image Occlusion export/import; add compatibility tests for the minimum supported version.
- [ ] Preserve stable GUIDs across content revisions so updates do not create duplicate notes.
- [ ] Add an export manifest mapping source ID + card type + evidence ID to Anki GUID and content hash.
- [ ] Add a dry-run update report: new, changed, unchanged, removed, and conflicted notes.
- [ ] Never delete or overwrite user-edited notes automatically; flag conflicts for review.
- [ ] Keep scheduling/review history inside Anki; do not modify FSRS scheduling data.
- [ ] Test repeated import, changed card content, changed media, deleted source, and changed note type.
- [ ] Add package integrity checks: media references resolve, all fields exist, note IDs are unique.

**Exit criteria:** repeated export/import does not create duplicate notes in the test collection and documented updates preserve review history.

### Phase 9 — usability, analytics, and release

- [ ] Add a summary dashboard/report: harvested, rejected, retained, visual assets, cards by type, warnings, and manual-review queue.
- [ ] Add per-specialty filters and a `--dry-run` mode.
- [ ] Add `--visual-only`, `--text-only`, `--max-visual-cards`, and `--include-asset-types` options.
- [ ] Add an optional Anki review-history importer only with explicit user consent; keep analytics local and avoid collecting free-text answers.
- [ ] Provide reproducible build metadata and a complete CHANGELOG.
- [ ] Add a clean install test on supported Python versions and an Anki import smoke test.
- [ ] Publish sample decks only when every source asset's licence permits redistribution.

**Exit criteria:** README examples work from a clean environment; release notes list schema migrations, known limitations, and licence behaviour.

## 4. Proposed card and asset data contracts

### Card record

```json
{
  "card_id": "stable-id",
  "case_id": "PMC1234567",
  "card_type": "radiology",
  "front_html": "...",
  "back_html": "...",
  "tags": ["specialty::urology", "card::radiology"],
  "evidence": [{"span_id": "span-001", "section_id": "sec-02"}],
  "asset_ids": ["fig-01-panel-a"],
  "review_state": "needs_review",
  "generator_version": "8.0.0"
}
```

### Visual asset record

```json
{
  "asset_id": "fig-01-panel-a",
  "case_id": "PMC1234567",
  "figure_number": "Figure 1",
  "panel": "A",
  "source_url": "https://...",
  "source_xml_sha256": "...",
  "asset_sha256": "...",
  "mime_type": "image/jpeg",
  "caption": "...",
  "license": "...",
  "license_decision": "allowed_for_personal_deck",
  "ocr_text": [],
  "visual_confidence": "needs_review"
}
```

These are illustrative contracts, not implemented schemas. A formal JSON Schema and migrations must be added in Phase 0.

## 5. V8 release gates

A V8 release is not ready until all of the following are true:

- [ ] Every exported clinical answer is traceable to source text or a dated external source.
- [ ] Every exported image has verified provenance, licence decision, checksum, and attribution.
- [ ] Retractions and corrections are screened and surfaced.
- [ ] Visual cards pass media, caption, answer-leak, and rendering checks.
- [ ] Human-review status is visible and low-confidence items are not silently auto-approved.
- [ ] Anki update tests demonstrate stable note identity and no accidental review-history loss.
- [ ] Unit, integration, offline fixture, and clean-install tests pass.
- [ ] Documentation distinguishes case-reported management from current guideline recommendations.

## 6. Recommended delivery order

1. Phase 0 regression tests and data contracts.
2. Phase 1 reliable/resumable harvesting.
3. Phase 2 status and licence gates.
4. Phase 3 structured JATS figures/tables.
5. Phase 4 safe media processing.
6. Phase 5 image occlusion + radiology cards first; pathology and comparison cards next.
7. Phase 6 evidence-locked exam cards.
8. Phase 7 quality review and clinician validation.
9. Phase 8 Anki update safety.
10. Phase 9 dashboard and release packaging.

**Do not start with OCR or an LLM-based image interpretation layer.** First preserve figure structure, source provenance, and licensing. Then add visual card generation that uses only verified source material.
