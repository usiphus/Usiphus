# Version 5.0 roadmap — proposed

Version 4.0 adds supplementary MeSH metadata, assertion attributes, evidence sentences, and more conservative diagnosis extraction. The next release should focus on **source reliability, validated clinical content, and more useful exam practice**.

## Highest-priority work

1. **Retraction, correction, and expression-of-concern screening**
   - Use the Europe PMC Article Status API (`POST /status-update`) to batch-check PMCID, PMID, and DOI identifiers before card generation; supplement with Crossref/Crossmark update metadata where useful.
   - Store status, date checked, source URL, and update relationships in `meta.json`.
   - Exclude retracted work by default; allow an explicit educational override with a prominent warning.
   - Crossref describes update relationships and Crossmark as a way to expose corrections, retractions, and updates. See the references below.

2. **Clinician-reviewed validation set**
   - Build a manually annotated set spanning specialties, age groups, and different JATS structures.
   - Measure diagnosis precision/recall, assertion certainty/temporality/experiencer, specialty precision, evidence-span correctness, and card factuality.
   - Publish errors and per-specialty results; do not report only one aggregate score.

3. **Evidence-locked card generation**
   - Represent each generated card as structured data with one or more exact source spans, section identifiers, and character offsets.
   - Reject answer facts that cannot be traced to the source.
   - Add an evidence field to TSV/APKG and a click-to-open source location in the preview.

4. **Guideline-aware learning cards (separate source layer)**
   - Add optional current guideline comparisons from authoritative professional societies or government sources.
   - Record guideline publisher, URL, publication/update date, recommendation strength, and access date.
   - Visually separate “reported in this case” from “current guideline recommendation”; never infer a guideline from a case report.

5. **Better clinical reasoning cards**
   - Generate next-best-investigation, interpretation, discriminating differential, complication, prognosis, and viva cards only when their evidence spans exist.
   - For “next best step”, require an independently sourced guideline/clinical pathway rather than guessing from case chronology.

## Additional ideas

6. **Structured concept normalization** — map diseases and procedures to MeSH/UMLS concepts where licensing and access permit; retain the original source wording.
7. **More robust assertion extraction** — optionally integrate a clinically evaluated assertion model, but keep rule-based fallbacks and expose model/version/confidence. Compare it against the V4 baseline on a labelled set before enabling it.
8. **Target saved count** — add `--target-saved` with bounded candidate refill so users can request a number of retained reports rather than a number of search results.
9. **Cross-source identity resolution** — link PMCID, PMID, DOI, preprint/version-of-record relationships, corrections, and duplicate titles without merging distinct clinical case reports.
10. **Figure and imaging support** — extract figure captions and optionally create image cards only when image reuse rights are clear; never treat an image caption as an imaging interpretation.
11. **Study analytics** — optionally import Anki review history to identify weak specialties, diagnoses, and card types; leave scheduling to Anki/FSRS.
12. **Quality gates** — add duplicate-front detection, answer-leak checks, card readability limits, malformed HTML checks, and per-article card caps.
13. **Incremental reprocessing** — re-run parsing/card generation when parser versions change while avoiding unnecessary full-text downloads.

## Proposed release gates

- No diagnosis card labelled high-confidence without a positive current patient assertion and a source evidence span.
- Retraction/correction status checked and visible; retracted articles excluded by default.
- A clinician-reviewed evaluation report with per-specialty metrics and documented failure cases.
- Every generated answer fact has traceable evidence.
- Guideline claims have an authoritative, dated source and are clearly distinguished from case-reported management.
- Licence-aware export rules tested before any public sharing or redistribution feature.

## Research and technical references

- Europe PMC REST API: `core` results can include full metadata and MeSH terms; the Annotations API exposes text-mined terms: https://dev.europepmc.org/RestfulWebService
- Europe PMC Article Status Monitor / programmatic status API: https://dev.europepmc.org/ArticleStatusMonitor (the `status-update` POST endpoint supports batched identifiers; see the Europe PMC developer announcement: https://groups.google.com/a/ebi.ac.uk/g/epmc-webservices/c/rKCPIEy1Uec)
- Europe PMC developer resources and retrieval options: https://dev.europepmc.org/developers
- Clinical NLP assertion detection: certainty, temporality, and experiencer are distinct attributes: https://pmc.ncbi.nlm.nih.gov/articles/PMC11908446/
- Crossref version control, corrections, and retractions: https://www.crossref.org/documentation/principles-practices/best-practices/versioning/
- Crossmark current status and update metadata: https://www.crossref.org/crossmark/
- Crossref REST API metadata, including post-publication updates: https://www.crossref.org/documentation/retrieve-metadata/rest-api/

The strongest V5 investment is not a larger language model by itself. It is a validated evidence pipeline that can detect when an article has been withdrawn or corrected and can prove where every flashcard answer came from.
