# Project roadmap index

This file is the navigation page for versioned project plans. It records what is present in the current project folder and what each document represents.

## Roadmap documents

| Version | Document | Status | Scope |
|---|---|---|---|
| V4.0 | [ROADMAP_v4.md](ROADMAP_v4.md) | Implemented baseline | MeSH-aware specialty relevance, assertion-aware diagnosis extraction, evidence sentence display, differential/pitfall cards, deduplication, provenance, and cache re-filtering. |
| V5.0 | [ROADMAP_v5.md](ROADMAP_v5.md) | Proposed | Retraction/correction screening, clinician validation, evidence-locked cards, guideline layer, improved reasoning cards, and quality gates. |
| V8.0 | [ROADMAP_v8.md](ROADMAP_v8.md) | Proposed | Reliable resumable harvesting, structured JATS/media extraction, visual card generation, evidence contracts, quality review, and safe Anki updates. |

## Version history notes

- V4 is the implementation baseline documented by the current `README.md` and source version constants.
- V5 is a proposal document; its features must not be described as implemented unless code and tests are added.
- V6 and V7 roadmap files were not present in the project directory at the time this index was created. They are not reconstructed or assumed here. Add them to this index if they exist elsewhere.
- V8 is a proposed roadmap, not a claim that visual extraction or visual cards are already implemented.

## Recommended reading order

1. [README.md](README.md) — installation, current CLI, outputs, and safety limitations.
2. [ROADMAP_v4.md](ROADMAP_v4.md) — delivered baseline.
3. [ROADMAP_v5.md](ROADMAP_v5.md) — source reliability and clinical validation proposals.
4. [ROADMAP_v8.md](ROADMAP_v8.md) — visual-first next-generation plan.
5. [BUG_AUDIT.md](BUG_AUDIT.md) — code review findings and fixes.
