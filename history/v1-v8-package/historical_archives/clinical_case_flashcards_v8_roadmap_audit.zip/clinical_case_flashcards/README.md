# Clinical Case Report → Exam Flashcards (Version 4.0)

> Roadmap index: [ROADMAPS.md](ROADMAPS.md) · [V4 implemented scope](ROADMAP_v4.md) · [V5 proposal](ROADMAP_v5.md) · [V8 visual-first proposal](ROADMAP_v8.md) · [Code audit](BUG_AUDIT.md)

A two-script workflow for finding open-access clinical case reports in Europe PMC and converting their JATS full text into source-linked, exam-style Anki cards. The pipeline is extractive and heuristic: it is a study aid, not a clinical decision system.

## What's new in 4.0

- **MeSH-aware specialty relevance:** the harvester makes a best-effort Europe PMC `core` metadata request and stores available MeSH descriptor terms. These add a capped relevance signal alongside title/abstract/full-text matches; they do not independently determine specialty.
- **Assertion-aware diagnosis extraction:** candidate diagnosis sentences are screened for common negation, uncertainty, historical, and family-member contexts. The quality report records certainty, temporality, experiencer, exact evidence sentence, and rejected candidates.
- **Evidence shown with diagnosis cards:** the extracted evidence sentence is displayed in the answer-side reading panel and included in the quality CSV.
- **Differential / pitfall cards:** generates cards only from sentences explicitly discussing alternatives or diagnostic pitfalls. Disable them with `--no-differential`. The card warns that article-discussed alternatives are not a complete validated differential.
- **Multi-key deduplication:** converter skips repeated PMCID/case IDs, normalized DOIs, and normalized exact titles within one deck-generation run.
- **Reproducibility metadata:** stores source XML SHA-256, harvester/parser version, MeSH terms, and retrieval timestamps in `meta.json`.
- **Cache re-filtering:** cached articles are checked against current word-count and specialty-relevance thresholds; missing plain-text copies are repaired. Older cache entries can be enriched with MeSH terms on the next run.
- **Year validation:** explicit year zero or out-of-range values no longer bypass validation.

## Install

Python 3.10 or newer is recommended.

```bash
python -m pip install -r requirements.txt
```

The harvester and TSV exporter use the Python standard library. `genanki` is required only for `.apkg` output.

## Example workflow

Harvest urology and cardiology case reports from 2018 onward:

```bash
python specialty_harvest.py --specialty urology cardiology --year-from 2018 --limit 40 --sort citations --output case_library
```

`--limit` means search candidates per specialty, not guaranteed retained reports. Full-text availability, word count, relevance, and educational filters can reduce the saved number.

Create Anki packages and an import TSV:

```bash
python cases2anki.py case_library --format both --output decks/clinical_cases --deck "Clinical Case Reports" --quality-report --preview
```

Create a urology TSV without differential cards:

```bash
python cases2anki.py case_library/urology --specialty urology --format tsv --output decks/urology --no-differential --quality-report
```

Create only a TSV without installing `genanki`:

```bash
python cases2anki.py case_library --format tsv --output decks/clinical_cases
```

Use `--skip-low-confidence-cases` to exclude cases whose diagnosis extraction confidence is below `--min-confidence`. Confidence is a rule-based review signal, **not a calibrated probability**.

## Outputs

Harvester output is organized by specialty and PMCID:

- `article.xml`: retrieved JATS source document.
- `article.txt`: plain-text reading copy.
- `meta.json`: bibliographic metadata, licence string, score breakdown, MeSH terms when available, source hash, parser version, and retrieval details.
- `manifest.jsonl`: cumulative index of retained cases.
- `harvest_errors.jsonl`: retrieval/search errors.

Converter output:

- `.tsv`: Anki-importable notes.
- `.apkg`: optional Anki package when `genanki` is installed.
- `.quality.csv`: diagnosis, assertion attributes, exact evidence sentence, rejected candidates, card types, and source details.
- `.preview.html`: local review preview when `--preview` is used.

## Supported specialties

`anesthesia`, `cardiology`, `cardiothoracic-surgery`, `dermatology`, `emergency-medicine`, `endocrinology`, `gastroenterology`, `general-surgery`, `hematology`, `infectious-disease`, `nephrology`, `neurology`, `neurosurgery`, `obstetrics-gynecology`, `oncology`, `ophthalmology`, `orthopedics`, `otolaryngology`, `pediatrics`, `psychiatry`, `pulmonology`, `radiology`, `rheumatology`, `urology`, `vascular-surgery`.

## Clinical and licensing safeguards

- Diagnosis extraction and assertion detection use regular expressions and local rules. They can miss complex negation, uncertainty, multiple diagnoses, pathology qualifiers, temporality, family attribution, or context spanning multiple sentences. Human review is mandatory before relying on a diagnosis card.
- MeSH availability varies by article and indexing status. The MeSH relevance score is only a supplementary signal and may be incomplete or too broad.
- Differential cards repeat only alternatives discussed by the authors; they are not a complete or validated differential diagnosis.
- Management cards describe what happened in one published case. They are **not** guideline recommendations and must not be generalized to patient care.
- The educational score is a transparent text-feature score, not a peer-review, evidence-quality, novelty, or clinical-importance rating.
- `OPEN_ACCESS:Y` and full-text availability do not by themselves grant unrestricted redistribution rights. The original article's licence and publisher terms govern reuse. Preserve attribution and do not redistribute copied full text unless the licence permits it. The scripts preserve licence metadata but do not make legal determinations.
- Version 4.0 does **not** yet perform authoritative retraction/correction screening, guideline comparison, or clinical validation. Those are planned for later versions.

## Offline tests

```bash
python -m unittest discover -s tests -v
python -m py_compile specialty_harvest.py cases2anki.py
```

The tests use synthetic JATS and mocked API responses. They do not establish live API compatibility, diagnosis accuracy, MeSH coverage, or clinical safety.

## Import TSV into Anki

In Anki, choose **File → Import**, select the `.tsv`, set the separator to **Tab**, map `Front`, `Back`, `Extra`, and `Tags`, and enable **Allow HTML in fields**. Choose the target deck and note type. If the first line is imported as a note, enable the option identifying it as a header row.
