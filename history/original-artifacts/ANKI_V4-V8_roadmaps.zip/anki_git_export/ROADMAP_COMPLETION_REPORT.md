# V4–V8 roadmap completion and release-gate report

**Audit date:** 2026-10-30
**Workspace:** local `8.1.0` implementation
**Overall status:** core educational pipeline foundations are implemented, but the complete V4–V8 production release is **not** complete. Items requiring external clinical governance, licensing decisions, credentials, or an Anki runtime remain explicitly blocked.

## Cross-version status

| Version | Delivered in this workspace | Still open / release gate |
|---|---|---|
| V4 | MeSH enrichment, heuristic assertion attributes, diagnosis evidence sentence, differential/pitfall cards, deduplication, provenance, cache re-filtering/repair, dotted output basenames. | Heuristic extraction limitations; no V5 status screening or clinician validation in the original V4 release. |
| V5 | Europe PMC status-update lookup; Crossref update-to lookup; explicit `unknown`/`conflict`; TTL cache and force refresh; retracted-source exclusion and warned override; bounded HTTP reads and numeric/date `Retry-After`; exact section-local evidence validation; local hash-bound append-only review decisions; separate guideline tables. | Clinician-adjudicated multi-specialty gold set and metrics; authenticated reviewer identity/roles and separation of duties; semantic coverage of every answer clause; maintained guideline allow-list and ingestion/review; Crossmark; persistent harvest checkpoints/resume; complete cache verification; live provider validation. |
| V6 | SQLite schema v1; idempotent JATS import; source XML hash verification; nested sections; FTS5; identity-conflict reporting; asset metadata; review-queue import; hash-bound local review history; JSONL manifest. | Populate concepts/events from reviewed annotations; deterministic full rebuild and dry-run diff; migration path beyond v1; larger real-world corpus validation; authenticated governance. |
| V7 | Stable card/evidence IDs; sentence evidence spans with section-local offsets; conservative author-reasoning cards; review queue and explicit decision import; approved-only and strict-evidence export gates; quality-report synchronization. | Authenticated reviewer identity; clinician-labelled evaluation; full semantic claim-level support; tamper-resistant audit service; expanded fuzz/property/end-to-end/performance tests; actual Anki import/update compatibility and history-preservation tests. |
| V8 | Deterministic JATS figure/table metadata inventory; source XML hash and source URL; graphic references/captions/licence metadata; fail-closed reuse state; no implicit downloads or embedding. | Human licence decision workflow; approved asset download and byte-level MIME/size/dimension/checksum validation; asset deduplication and safe processing; image-caption review; image occlusion/visual card generators; visual review UX; stable note GUIDs and dry-run conflict-safe Anki updates. |

## Safety rules retained

- A case report is not a guideline or universal recommendation.
- An unknown article status is not treated as current. Confirmed retractions are excluded unless the explicit historical-study override is used, in which case generated cards carry a warning.
- Unknown or unreviewed asset reuse rights block automatic embedding and redistribution.
- A model score, user-supplied reviewer label, or successful unit test is not clinician approval.
- Existing Anki scheduling/review history must not be overwritten; safe update semantics are not claimed until integration-tested.

## Verification actually performed

- `python -m unittest discover -s tests -q`: **51 tests passed** (offline fixtures and mocked provider responses).
- `python -m py_compile specialty_harvest.py cases2anki.py source_integrity.py case_database.py tests/*.py`: passed.
- SQLite CLI smoke test: database initialization, import, FTS search, manifest export, `PRAGMA integrity_check`, and `PRAGMA foreign_key_check` passed.
- ZIP integrity and patch applicability against the original README baseline were checked.

## Not performed (do not infer completion)

- No live Europe PMC or Crossref API verification in this test run.
- No clinician review, adjudication, gold-standard dataset, or clinical performance metrics.
- No authenticated reviewer/role/separation-of-duties integration.
- No legal/licence adjudication or permission to redistribute any figure.
- No real Anki collection import, update, or review-history preservation test.
- No production-scale corpus, cross-platform, fuzz, or performance qualification.

## Release decision

This workspace is suitable as a tested development foundation and for carefully supervised educational experimentation. It must **not** be described as a fully validated clinical product or a complete visual-card release. Close the external gates above before making those claims.
