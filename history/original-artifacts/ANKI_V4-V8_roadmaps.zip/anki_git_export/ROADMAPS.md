# Unified project roadmap — V1 through V8

This index is the source of truth for version history. A version is labelled implemented only when corresponding code or a preserved release artifact can be inspected. A design document or archived snapshot is not proof that all planned features shipped.

## Version status

| Version | Evidence in this workspace | Status | Role |
|---|---|---|---|
| V1 | No separately identifiable V1 source tree or release archive | Historical record missing | Original prototype; scope cannot be reconstructed reliably |
| V2 | No separately identifiable V2 source tree or release archive | Historical record missing | Intermediate iteration; scope cannot be reconstructed reliably |
| V3 | `clinical_case_flashcards_v3.0.zip` | Archived release snapshot | Conservative diagnosis extraction, quality CSV, differential/pitfall cards, basic QA, DOI deduplication, cache re-filtering |
| V4 | `ROADMAP_v4.md`, V4 code baseline and tests | Implemented baseline | MeSH relevance, assertion attributes, evidence sentence display, differential cards, deduplication, provenance, cache repair/re-filtering |
| V5 | `ROADMAP_v5.md` | Partial implementation; clinical-safety release blocked | Europe PMC/Crossref status checks, retraction gate, bounded HTTP/retry handling, local hash-bound review; clinician validation, authenticated identity, semantic claim coverage, guideline governance and resumable harvest remain open |
| V6 | `ROADMAP_v6.md` | Partial implementation (SQLite schema v1) | Idempotent JATS import, exact evidence validation, FTS5, conflict flags, asset metadata and local review history; concept/event annotation population, deterministic rebuild/diff and authenticated governance remain open |
| V7 | `ROADMAP_v7.md`, current source/tests | Core workflow implemented locally; production gates open | Stable card/evidence IDs, section-local spans, author-reasoning cards, review queue/decision import, strict-evidence export; authentication, clinician validation and complete semantic claim checking remain open |
| V8 | `ROADMAP_v8.md`, current source/tests | Media-inventory foundation implemented; visual release incomplete | Metadata-only figure/table inventory with fail-closed licensing; licensed asset download/validation, visual cards, image review UX and safe Anki update integration remain open |

## Version dependency chain

```text
V1 prototype (historical source not preserved)
  -> V2 iteration (historical source not preserved)
  -> V3 archived functional release
  -> V4 stronger extraction, metadata, evidence and QA baseline
  -> V5 source integrity, clinician validation and claim-level evidence specification
  -> V6 structured specialty case knowledge base design
  -> V7 evidence IDs, review workflow and strict export controls
  -> V8 structured JATS media inventory and visual-card foundation
```

## Combined release principles

1. Preserve inspectable historical archives; never overwrite older versions with newer code.
2. Keep original XML and metadata immutable; generated cards and media manifests are derived artifacts.
3. Every clinical card is educational and source-linked, not patient-specific medical advice.
4. Case-reported management must never be presented as a guideline.
5. Unknown article/asset licence means no automatic image embedding or redistribution.
6. Human approval must not be inferred from a model score or reviewer field.
7. A passing offline test suite does not close clinical, licensing, authentication, live-provider, or real-Anki release gates; see `ROADMAP_COMPLETION_REPORT.md`.

## Recommended reading order

1. `README.md` — setup and commands.
2. `ROADMAPS.md` — this version history.
3. `ROADMAP_v4.md` — delivered V4 baseline.
4. `ROADMAP_v5.md` — strengthened source-integrity and validation plan.
5. `ROADMAP_v6.md` — structured database design.
6. `ROADMAP_v7.md` — evidence and review implementation.
7. `ROADMAP_v8.md` — V8 media foundation and remaining work.
8. `BUG_AUDIT.md` — audit and verification record.

## Historical archive notes

- `clinical_case_flashcards.zip` and `clinical_case_flashcards_reviewed.zip` are retained as legacy snapshots; neither archive identifies itself as V1 or V2.
- `clinical_case_flashcards_v3.0.zip` is explicitly labelled V3.
- The combined package includes legacy snapshots but does not fabricate V1/V2 roadmap files or claim their exact feature sets.
- V4 was repeated in the request; it is included once as a version, with historical snapshots retained separately.

## 8.1.0 delivery update (2026-10-30)

- V5: optional Europe PMC + Crossref status screening, explicit unknown/conflict states, TTL cache, default retraction exclusion, warned historical override, bounded HTTP reads, and HTTP-date `Retry-After` handling are implemented. Clinician-labelled evaluation, authenticated review, full claim-level support validation, Crossmark integration, guideline allow-list governance, and durable resumable checkpoints remain open.
- V6: SQLite schema v1, idempotent JATS imports, hash verification, nested sections, FTS5, identity conflict reporting, asset metadata, review-card/evidence import, hash-bound append-only local review decisions, and JSONL manifest export are implemented. Concept/event population, complete rebuild/diff tooling, and institutional governance remain incomplete.
- Verification: 51 offline unit tests pass; Python compilation and SQLite CLI smoke tests pass. No live API run, clinician adjudication, authenticated reviewer test, licensed asset review, or real Anki collection import was performed.
