import json
import unittest

import guideline_sources as gs


PUBMED_XML = b'''<?xml version="1.0"?>
<PubmedArticleSet><PubmedArticle><MedlineCitation><PMID>12345</PMID><Article>
<ArticleTitle>Clinical practice guideline for acute urinary retention</ArticleTitle>
<Journal><Title>Example Journal of Urology</Title><JournalIssue><PubDate><Year>2025</Year><Month>Feb</Month><Day>3</Day></PubDate></JournalIssue></Journal>
<Abstract><AbstractText Label="BACKGROUND">Background text.</AbstractText><AbstractText Label="RECOMMENDATIONS">Recommendation summary in abstract.</AbstractText></Abstract>
<PublicationTypeList><PublicationType>Practice Guideline</PublicationType></PublicationTypeList>
</Article></MedlineCitation><PubmedData><ArticleIdList><ArticleId IdType="doi">10.1000/example</ArticleId></ArticleIdList></PubmedData></PubmedArticle></PubmedArticleSet>'''


class GuidelineSourceTests(unittest.TestCase):
    def test_query_requires_topic_and_uses_guideline_publication_types(self):
        with self.assertRaises(ValueError):
            gs.build_pubmed_query("  ")
        query = gs.build_pubmed_query("acute urinary retention")
        self.assertIn('"Practice Guideline"[Publication Type]', query)
        self.assertIn('"Guideline"[Publication Type]', query)
        self.assertIn("acute urinary retention", query)

    def test_parse_pubmed_metadata_without_creating_recommendation(self):
        rows = gs.parse_pubmed_xml(PUBMED_XML, accessed_at="2026-10-30")
        self.assertEqual(len(rows), 1)
        row = rows[0]
        self.assertEqual(row["guideline_id"], "pubmed:12345")
        self.assertEqual(row["publication_date"], "2025-02-03")
        self.assertEqual(row["doi"], "10.1000/example")
        self.assertEqual(row["publisher"], "PubMed (NCBI indexing service)")
        self.assertEqual(row["journal"], "Example Journal of Urology")
        self.assertIn("RECOMMENDATIONS: Recommendation summary", row["abstract"])
        self.assertNotIn("recommendation_text", row)
        self.assertEqual(row["stable_url"], "https://pubmed.ncbi.nlm.nih.gov/12345/")

    def test_search_calls_esearch_then_efetch_and_respects_limit(self):
        calls = []
        def fake_get(url, **kwargs):
            calls.append((url, kwargs))
            if "esearch.fcgi" in url:
                return json.dumps({"esearchresult": {"idlist": ["12345"]}}).encode()
            return PUBMED_XML
        rows = gs.search_pubmed_guidelines("acute urinary retention", limit=5, get=fake_get,
                                           accessed_at="2026-10-30")
        self.assertEqual(len(rows), 1)
        self.assertEqual(len(calls), 2)
        self.assertIn("retmax=5", calls[0][0])
        self.assertIn("12345", calls[1][0])

    def test_search_empty_results_skips_fetch(self):
        calls = []
        def fake_get(url, **kwargs):
            calls.append(url)
            return b'{"esearchresult":{"idlist":[]}}'
        self.assertEqual(gs.search_pubmed_guidelines("rare condition", get=fake_get), [])
        self.assertEqual(len(calls), 1)

    def test_parse_eau_index_extracts_only_top_level_guideline_pages(self):
        html = b'''<html><body>
          <a href="/guidelines/prostate-cancer">Prostate Cancer</a>
          <a href="/guidelines/urological-infections/">Urological Infections</a>
          <a href="/guidelines/prostate-cancer/chapter/diagnosis">Diagnosis chapter</a>
          <a href="/guidelines">Guidelines home</a>
        </body></html>'''
        rows = gs.parse_eau_guideline_index(html, query="urological infections", accessed_at="2026-10-30")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["guideline_id"], "eau:urological-infections")
        self.assertEqual(rows[0]["publisher"], "European Association of Urology")
        self.assertEqual(rows[0]["stable_url"], "https://uroweb.org/guidelines/urological-infections/")
        self.assertEqual(rows[0]["publication_date"], "")
        self.assertNotIn("recommendation_text", rows[0])

    def test_medline_date_preserves_year_without_inventing_month_or_day(self):
        xml = b'''<PubmedArticleSet><PubmedArticle><MedlineCitation><PMID>77</PMID><Article>
        <ArticleTitle>Guideline</ArticleTitle><Journal><Title>Journal</Title><JournalIssue><PubDate><MedlineDate>2024 Dec-2025 Jan</MedlineDate></PubDate></JournalIssue></Journal>
        </Article></MedlineCitation></PubmedArticle></PubmedArticleSet>'''
        row = gs.parse_pubmed_xml(xml, accessed_at="2026-10-30")[0]
        self.assertEqual(row["publication_date"], "2024")

    def test_eau_search_uses_official_index(self):
        calls = []
        def fake_get(url, **kwargs):
            calls.append((url, kwargs))
            return b'<a href="/guidelines/paediatric-urology">Paediatric Urology</a>'
        rows = gs.search_eau_guidelines("paediatric urology", get=fake_get, accessed_at="2026-10-30")
        self.assertEqual(len(rows), 1)
        self.assertEqual(calls[0][0], gs.EAU_GUIDELINES_INDEX)
        self.assertEqual(calls[0][1]["accept"], "text/html")


if __name__ == "__main__":
    unittest.main()
