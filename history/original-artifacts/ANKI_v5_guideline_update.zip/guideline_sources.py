#!/usr/bin/env python3
"""Discover clinical practice guideline citations through the official NCBI PubMed API.

PubMed is a discovery/indexing source, not the issuing guideline publisher. This module
imports citation metadata and abstracts only. It deliberately does not manufacture
recommendation statements or strength grades from abstracts.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import sys
import urllib.parse
from html.parser import HTMLParser
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Callable

from specialty_harvest import http_get

EUTILS = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
EAU_GUIDELINES_INDEX = "https://uroweb.org/guidelines"
USER_AGENT = "ANKI-clinical-guideline-discovery/5.0 (educational research; contact: project maintainers)"


def build_pubmed_query(topic: str) -> str:
    topic = re.sub(r"\s+", " ", topic).strip()
    if not topic:
        raise ValueError("A clinical topic is required")
    # PubMed publication-type filters restrict results to indexed guideline records.
    return f'(({topic}) AND ("Practice Guideline"[Publication Type] OR "Guideline"[Publication Type]))'


def _text(node: ET.Element | None) -> str:
    if node is None:
        return ""
    return re.sub(r"\s+", " ", " ".join(node.itertext())).strip()


def _publication_date(article: ET.Element) -> str:
    date_node = article.find(".//JournalIssue/PubDate")
    if date_node is None:
        date_node = article.find(".//PubDate")
    if date_node is None:
        return ""
    year = _text(date_node.find("Year"))
    month = _text(date_node.find("Month"))
    day = _text(date_node.find("Day"))
    if year and year.isdigit():
        month_names = ("January", "February", "March", "April", "May", "June", "July", "August",
                       "September", "October", "November", "December")
        months = {name.lower(): f"{i:02d}" for i, name in enumerate(month_names, 1)}
        months.update({name[:3].lower(): f"{i:02d}" for i, name in enumerate(month_names, 1)})
        month_num = months.get(month.lower(), month.zfill(2) if month.isdigit() else "")
        if month_num and day.isdigit():
            return f"{year}-{month_num}-{day.zfill(2)}"
        if month_num:
            return f"{year}-{month_num}-01"
        return f"{year}-01-01"
    medline_date = _text(date_node.find("MedlineDate"))
    year_match = re.search(r"\b(?:19|20)\d{2}\b", medline_date)
    return year_match.group(0) if year_match else ""


def parse_pubmed_xml(payload: bytes | str, *, accessed_at: str | None = None) -> list[dict[str, str]]:
    root = ET.fromstring(payload)
    accessed = accessed_at or dt.date.today().isoformat()
    records: list[dict[str, str]] = []
    for item in root.findall(".//PubmedArticle"):
        citation = item.find(".//MedlineCitation")
        article = citation.find("Article") if citation is not None else None
        if article is None:
            continue
        pmid = _text(citation.find("PMID")) if citation is not None else ""
        title = _text(article.find("ArticleTitle"))
        if not pmid or not title:
            continue
        journal = _text(article.find("Journal/Title")) or "PubMed indexed record"
        abstract_parts = []
        abstract = article.find("Abstract")
        if abstract is not None:
            for part in abstract.findall("AbstractText"):
                label = part.attrib.get("Label", "").strip()
                value = _text(part)
                if value:
                    abstract_parts.append(f"{label}: {value}" if label else value)
        doi = ""
        for identifier in item.findall(".//ArticleId"):
            if identifier.attrib.get("IdType", "").lower() == "doi":
                doi = _text(identifier)
                break
        publication_types = [
            _text(x) for x in article.findall("PublicationTypeList/PublicationType") if _text(x)
        ]
        pub_date = _publication_date(article)
        records.append({
            "guideline_id": f"pubmed:{pmid}",
            "publisher": "PubMed (NCBI indexing service)",
            "journal": journal,
            "title": title,
            "stable_url": f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/",
            "publication_date": pub_date,
            "last_updated": "",
            "accessed_at": accessed,
            "version": f"PubMed PMID {pmid}",
            "source_database": "PubMed",
            "source_record_id": pmid,
            "doi": doi,
            "abstract": "\n".join(abstract_parts),
            "source_label": "PubMed-indexed guideline citation; verify current version and recommendations at the issuing publisher",
            "publication_types": "; ".join(publication_types),
            # Intentionally no recommendation_text/strength_grade here.
        })
    return records


def search_pubmed_guidelines(topic: str, *, limit: int = 25,
                              get: Callable[..., bytes] = http_get,
                              accessed_at: str | None = None) -> list[dict[str, str]]:
    if limit < 1 or limit > 200:
        raise ValueError("limit must be between 1 and 200")
    query = build_pubmed_query(topic)
    search_url = EUTILS + "/esearch.fcgi?" + urllib.parse.urlencode({
        "db": "pubmed", "term": query, "retmode": "json", "retmax": str(limit),
        "sort": "date",
    })
    search_data = json.loads(get(search_url, accept="application/json", user_agent=USER_AGENT))
    ids = search_data.get("esearchresult", {}).get("idlist", [])
    if not ids:
        return []
    fetch_url = EUTILS + "/efetch.fcgi?" + urllib.parse.urlencode({
        "db": "pubmed", "id": ",".join(ids), "retmode": "xml",
    })
    return parse_pubmed_xml(get(fetch_url, accept="application/xml", user_agent=USER_AGENT),
                             accessed_at=accessed_at)



class _EAUGuidelineLinks(HTMLParser):
    """Extract only top-level guideline pages from the official EAU index."""
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.links: list[tuple[str, str]] = []
        self._href = ""
        self._parts: list[str] = []

    def handle_starttag(self, tag: str, attrs) -> None:
        if tag.lower() == "a":
            values = dict(attrs)
            href = values.get("href", "")
            if re.fullmatch(r"/guidelines/[a-z0-9-]+/?", href, flags=re.I):
                self._href = href
                self._parts = []

    def handle_data(self, data: str) -> None:
        if self._href:
            self._parts.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "a" and self._href:
            title = re.sub(r"\s+", " ", " ".join(self._parts)).strip()
            if title:
                self.links.append((self._href, title))
            self._href = ""
            self._parts = []


def parse_eau_guideline_index(payload: bytes | str, *, query: str = "",
                              accessed_at: str | None = None) -> list[dict[str, str]]:
    parser = _EAUGuidelineLinks()
    parser.feed(payload.decode("utf-8", errors="replace") if isinstance(payload, bytes) else payload)
    terms = [x.lower() for x in re.findall(r"[a-z0-9]+", query)]
    accessed = accessed_at or dt.date.today().isoformat()
    rows = []
    seen = set()
    for href, title in parser.links:
        url = urllib.parse.urljoin("https://uroweb.org", href)
        if url in seen:
            continue
        seen.add(url)
        if terms and not all(term in title.lower() for term in terms):
            continue
        slug = href.rstrip("/").rsplit("/", 1)[-1]
        rows.append({
            "guideline_id": f"eau:{slug}",
            "publisher": "European Association of Urology",
            "journal": "",
            "title": title,
            "stable_url": url,
            "publication_date": "",
            "last_updated": "",
            "accessed_at": accessed,
            "version": "Not stated in catalogue; verify edition on publisher page",
            "source_database": "EAU official guideline catalogue",
            "source_record_id": slug,
            "doi": "",
            "abstract": "",
            "source_label": "Official EAU guideline index entry; verify current edition and recommendation text on the publisher page",
        })
    return rows


def search_eau_guidelines(query: str = "", *, get: Callable[..., bytes] = http_get,
                          accessed_at: str | None = None) -> list[dict[str, str]]:
    html = get(EAU_GUIDELINES_INDEX, accept="text/html", user_agent=USER_AGENT)
    return parse_eau_guideline_index(html, query=query, accessed_at=accessed_at)

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Discover PubMed-indexed clinical practice guidelines")
    parser.add_argument("--source", choices=("pubmed", "eau"), default="pubmed",
                        help="PubMed indexed guideline discovery or the official EAU guideline catalogue")
    parser.add_argument("--query", default="", help="Clinical topic (required for PubMed; optional title filter for EAU)")
    parser.add_argument("--limit", type=int, default=25, help="Maximum PubMed citations to retrieve (1-200)")
    parser.add_argument("--output", type=Path, required=True, help="Output JSONL file for ANKI guideline import")
    args = parser.parse_args(argv)
    try:
        if args.source == "pubmed":
            if not args.query.strip():
                parser.error("--query is required when --source=pubmed")
            records = search_pubmed_guidelines(args.query, limit=args.limit)
        else:
            records = search_eau_guidelines(args.query)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text("".join(json.dumps(x, ensure_ascii=False) + "\n" for x in records), encoding="utf-8")
        print(json.dumps({"records": len(records), "output": str(args.output),
                          "note": "Source entries only; verify current publisher version and manually curate recommendation claims."}))
        return 0
    except (OSError, ValueError, json.JSONDecodeError, ET.ParseError, RuntimeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
