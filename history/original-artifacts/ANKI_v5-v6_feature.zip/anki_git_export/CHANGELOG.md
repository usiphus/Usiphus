# Changelog

## 8.1.0 — 2026-10-30

### Added
- Optional Europe PMC status-update-search and Crossref update-to screening with TTL cache.
- Conservative status normalization; unknown and provider conflicts remain explicit.
- Default exclusion of confirmed retractions from card export; explicit warned override for historical study.
- Bounded HTTP response reads and numeric/HTTP-date Retry-After handling.
- SQLite schema v1 with normalized article, section, evidence, concept, event, asset, card, review, identity-conflict, and separate guideline tables.
- Idempotent case-folder imports, FTS5 search, source hash validation, nested JATS sections, media inventory indexing, and JSONL manifest export.
- Review queue import with exact section-offset validation and local append-only hash-bound review decisions.
- Expanded offline regression suite.

### Limitations
- No clinician-adjudicated gold dataset or clinical performance metrics.
- Reviewer identity is not authenticated; local append-only triggers are not a tamper-proof audit system.
- No full semantic claim-support validator, institutional guideline allow-list workflow, or durable harvest checkpoint/resume system.
- No live API verification or real Anki collection import was performed for this release.
- V8 visual-card generation, OCR, image download, and image-occlusion generation remain unimplemented.
