# Pull request: V5/V6 safety and database foundations (8.1.0)

## Summary

- Add optional Europe PMC `status-update-search` and Crossref `update-to` screening with TTL caching and explicit `unknown` / `conflict` outcomes.
- Exclude explicitly retracted articles from ordinary card exports; require an explicit override for historical use and attach a warning to every overridden card.
- Bound HTTP response reads and support numeric and HTTP-date `Retry-After` delays.
- Add a versioned SQLite knowledge-base foundation with idempotent JATS import, source-hash verification, FTS5 search, identity-conflict records, media inventory, evidence spans, card claims, and separate guideline tables.
- Validate review-queue offsets against exact source text; store local append-only decisions bound to card, evidence, and source hashes.
- Preserve the previous release archives and unclassified legacy material without inventing V1/V2 labels.
- Add CI for Python 3.10–3.13.

## Verification

- `python -m py_compile specialty_harvest.py cases2anki.py source_integrity.py case_database.py tests/*.py`
- `python -m unittest discover -s tests -v` — 51 tests passed.
- SQLite CLI smoke test: initialize, import, FTS search, manifest export, and integrity check passed.

## Safety and scope notes

This is a partial V5/V6 implementation, not a claim that all roadmap gates are complete. Status checks are best-effort; unknown is not current. No clinician-adjudicated gold set, authenticated reviewer identity, complete semantic claim-support validator, Crossmark adapter, maintained guideline allow-list, durable harvest checkpointing, image download, visual-card generation, or real Anki collection update test is included. No live Europe PMC/Crossref request or clinician adjudication was performed in this offline run.
