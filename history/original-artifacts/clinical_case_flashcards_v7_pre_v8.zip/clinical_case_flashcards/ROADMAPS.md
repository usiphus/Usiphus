# Project roadmap index

This file is the navigation page for versioned project plans. It records what is present in the current project folder and what each document represents.

## Roadmap documents

| Version | Document | Status | Scope |
|---|---|---|---|
| V4.0 | [ROADMAP_v4.md](ROADMAP_v4.md) | Implemented baseline | MeSH-aware specialty relevance, assertion-aware diagnosis extraction, evidence sentence display, differential/pitfall cards, deduplication, provenance, and cache re-filtering. |
| V5.0 | [ROADMAP_v5.md](ROADMAP_v5.md) | Proposed | Retraction/correction screening, clinician validation, evidence-locked cards, guideline layer, improved reasoning cards, and quality gates. |
| V6.0 | Not present | Planning concept only | Specialty-specific scholarly article discovery and structured clinical case database; proposed in the V6 design discussion, but no standalone roadmap or database implementation is present here. |
| V7.0 | [ROADMAP_v7.md](ROADMAP_v7.md) | Partially implemented locally | Evidence spans and stable IDs, author-stated reasoning cards, quality flags, review queue export, strict-evidence filtering, and pre-V8 release gates. |
| V8.0 | [ROADMAP_v8.md](ROADMAP_v8.md) | Proposed | Reliable resumable harvesting, structured JATS/media extraction, visual card generation, evidence contracts, quality review, and safe Anki updates. |

## Version history notes

- V4 is the implementation baseline documented by the current `README.md` and source version constants.
- V5 remains a proposal; features such as authoritative retraction monitoring and guideline retrieval are not implemented merely because they appear in that plan.
- V6 is represented by a planning concept for a specialty-specific clinical case database; it has not been implemented in this local Python project.
- V7 code changes are present locally, but clinician validation, retraction checks, guideline sourcing, and a reviewer decision-import workflow remain open. See [ROADMAP_v7.md](ROADMAP_v7.md).
- V8 is a proposed roadmap, not a claim that visual extraction or visual cards are already implemented.

## Recommended reading order

1. [README.md](README.md) — installation, current CLI, outputs, and safety limitations.
2. [ROADMAP_v4.md](ROADMAP_v4.md) — delivered baseline.
3. [ROADMAP_v5.md](ROADMAP_v5.md) — source reliability and clinical validation proposals.
4. [ROADMAP_v7.md](ROADMAP_v7.md) — advanced reasoning, quality review, and pre-V8 gates.
5. [ROADMAP_v8.md](ROADMAP_v8.md) — visual-first next-generation plan.
6. [BUG_AUDIT.md](BUG_AUDIT.md) — code review findings and fixes.
